const agents = [
    {
      name: 'Harvey Spector',
      role: 'Lawyer',
      description: 'Experienced lawyer specializing in corporate law and litigation.',
      imageUrl1: '/api/media/lawyer1',
      imageUrl2: '/api/media/lawyer2',
      href: '/chat/lawyer'
    },
  ];

  
export default agents; 